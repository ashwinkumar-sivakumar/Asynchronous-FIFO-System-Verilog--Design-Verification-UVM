The directed testcases are given in the file "test.txt" which is taken as input in the sequence block 
Use the makefile "run.do" to run the testbench , follow the comments given in the run.do file to enable the respective coverage details
