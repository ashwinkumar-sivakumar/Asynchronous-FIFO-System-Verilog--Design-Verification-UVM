var g_db_data = {"12":1,"10":1,"4":1,"7":1,"8":1,"5":1,"6":1,"9":1};
processScopesDbFile(g_db_data);